////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _COLOR_C_
#define _COLOR_C_

#include "datatype.h"
#include "msAPI_Mode.h"
//------------------------------------------------------------------------------
// sRGB Transform Matrix
//------------------------------------------------------------------------------
code short  tSRGB[3][3] =
{
    { 1096, -43, -28 }, // R  1.0694, -0.0424, -0.0270
    { - 21,   1063, -18 }, // G -0.0204,  1.0376, -0.0172
    { - 1,   34,   991 }  // B -0.0009,  0.0330,  0.9679


};
//------------------------------------------------------------------------------
// Color Correcttion Matrix
//------------------------------------------------------------------------------
// Smooth (X)
// R Array (0,0), G Array (0,0), B Array (0,0)
// R Adj. (0), G Adj. (0), B Adj. (0)
code short  tDefaultColorCorrectionMatrix[] =
{
   0x0400, 0x0000, 0x0000, 0x0000, 0x0400, 0x0000, 0x0000, 0x0000, 
   0x0400,-0x02E6, 0x0288,-0x05BB, 0x07A4,-0x062C, 0x06F3,-0x073C,  
  -0x0024, 0x01BF, 0x07EF,-0x0116, 0x01EE, 0x052C,-0x03BB, 0x00B1,  
  -0x0831, 0x0100,-0x0000, 0x0000,-0x0000, 0x0000, 0x0000, 0x0000,  
};

// Smooth (X)
// R Array (0,0), G Array (0,0), B Array (0,0)
// R Adj. (0), G Adj. (0), B Adj. (0)
code short  tVideoColorCorrectionMatrix[] =
{
   0x0400, 0x0000, 0x0000, 0x0000, 0x0400, 0x0000, 0x0000, 0x0000, 
   0x0400,-0x02E6, 0x0288,-0x05BB, 0x07A4,-0x062C, 0x06F3,-0x073C,  
  -0x0024, 0x01BF, 0x07EF,-0x0116, 0x01EE, 0x052C,-0x03BB, 0x00B1,  
  -0x0831, 0x0100,-0x0000, 0x0000,-0x0000, 0x0000, 0x0000, 0x0000,  
};

// Smooth (X)
// R Array (0,0), G Array (0,0), B Array (0,0)
// R Adj. (0), G Adj. (0), B Adj. (0)
code short  tHDTVColorCorrectionMatrix[] =
{
   0x0400, 0x0000, 0x0000, 0x0000, 0x0400, 0x0000, 0x0000, 0x0000, 
   0x0400,-0x02E6, 0x0288,-0x05BB, 0x07A4,-0x062C, 0x06F3,-0x073C,  
  -0x0024, 0x01BF, 0x07EF,-0x0116, 0x01EE, 0x052C,-0x03BB, 0x00B1,  
  -0x0831, 0x0100,-0x0000, 0x0000,-0x0000, 0x0000, 0x0000, 0x0000,  
};

// Smooth (X)
// R Array (0,0), G Array (0,0), B Array (0,0)
// R Adj. (0), G Adj. (0), B Adj. (0)
code short  tSDTVColorCorrectionMatrix[] =
{
   0x0400, 0x0000, 0x0000, 0x0000, 0x0400, 0x0000, 0x0000, 0x0000, 
   0x0400,-0x02E6, 0x0288,-0x05BB, 0x07A4,-0x062C, 0x06F3,-0x073C,  
  -0x0024, 0x01BF, 0x07EF,-0x0116, 0x01EE, 0x052C,-0x03BB, 0x00B1,  
  -0x0831, 0x0100,-0x0000, 0x0000,-0x0000, 0x0000, 0x0000, 0x0000,  
};

// Smooth (X)
// R Array (0,0), G Array (0,0), B Array (0,0)
// R Adj. (0), G Adj. (0), B Adj. (0)
code short  tATVColorCorrectionMatrix[] =
{
   0x0400, 0x0000, 0x0000, 0x0000, 0x0400, 0x0000, 0x0000, 0x0000, 
   0x0400,-0x02E6, 0x0288,-0x05BB, 0x07A4,-0x062C, 0x06F3,-0x073C,  
  -0x0024, 0x01BF, 0x07EF,-0x0116, 0x01EE, 0x052C,-0x03BB, 0x00B1,  
  -0x0831, 0x0100,-0x0000, 0x0000,-0x0000, 0x0000, 0x0000, 0x0000,  
};

// Smooth (X)
// R Array (0,0), G Array (0,0), B Array (0,0)
// R Adj. (0), G Adj. (0), B Adj. (0)
code short  tSDYPbPrColorCorrectionMatrix[] =
{
   0x0400, 0x0000, 0x0000, 0x0000, 0x0400, 0x0000, 0x0000, 0x0000, 
   0x0400,-0x02E6, 0x0288,-0x05BB, 0x07A4,-0x062C, 0x06F3,-0x073C,  
  -0x0024, 0x01BF, 0x07EF,-0x0116, 0x01EE, 0x052C,-0x03BB, 0x00B1,  
  -0x0831, 0x0100,-0x0000, 0x0000,-0x0000, 0x0000, 0x0000, 0x0000,  
};

// Smooth (X)
// R Array (0,0), G Array (0,0), B Array (0,0)
// R Adj. (0), G Adj. (0), B Adj. (0)
code short  tHDYPbPrColorCorrectionMatrix[] =
{
   0x0400, 0x0000, 0x0000, 0x0000, 0x0400, 0x0000, 0x0000, 0x0000, 
   0x0400,-0x02E6, 0x0288,-0x05BB, 0x07A4,-0x062C, 0x06F3,-0x073C,  
  -0x0024, 0x01BF, 0x07EF,-0x0116, 0x01EE, 0x052C,-0x03BB, 0x00B1,  
  -0x0831, 0x0100,-0x0000, 0x0000,-0x0000, 0x0000, 0x0000, 0x0000,  
};

#undef _COLOR_C_
#endif /* _COLOR_C_ */

